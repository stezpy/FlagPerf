#!/bin/bash
ls /usr/local | grep cuda | grep -v "backup" >/dev/null
if [ $? -eq 0 ] && [ "$1" != "-f" ]; then
    echo "/usr/local 下已经有cuda, 请先自己处理"
    echo "或者加-f参数,脚本会自动帮你备份实体,但不会帮你备份链接"
    exit 1
fi

script_dir=$(cd $(dirname $0);pwd)
rpj_time_stamp=`date +%Y-%m-%d_%H_%M_%S`backup

if [ -e /usr/local/cuda ]
then 
    cuda_path=`readlink -f /usr/local/cuda`
    echo 备份
    mv -v ${cuda_path} $cuda_path$rpj_time_stamp
fi

#删除/usr/local下所有cuda文件夹 但是不删除备份
cd /usr/local
ls /usr/local | grep cuda | grep -v "backup" | xargs -n 1 rm -rf

cd $script_dir
my_cuda_folder=${script_dir}/cuda
chmod -R 777 ${my_cuda_folder}
cp -rpf ${my_cuda_folder} /usr/local/cuda-10.2
ln -sf /usr/local/cuda-10.2 /usr/local/cuda
echo 列出新安装的cuda头文件
ls -lh /usr/local | grep cuda | grep -v "backup"